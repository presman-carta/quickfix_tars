import quickfix as fix
import quickfix42 as fix42
import unittest

class PostgreSQLStoreTestCase(unittest.TestCase):

    def setUp(self):
        self.settings = fix.SessionSettings()
        sessionID = fix.SessionID( "FIX.4.2", "SenderCompID", "TargetCompID" )
        dictionary = fix.Dictionary()
        dictionary.setString( fix.CONNECTION_TYPE, 'acceptor' )

        dictionary.setString( fix.POSTGRESQL_STORE_DATABASE, 'quickfix' )
        dictionary.setString( fix.POSTGRESQL_STORE_USER, 'db_user' )
        dictionary.setString( fix.POSTGRESQL_STORE_PASSWORD, 'db_password' )
        dictionary.setString( fix.POSTGRESQL_STORE_HOST, 'localhost' )

        dictionary.setString( fix.POSTGRESQL_LOG_DATABASE, 'quickfix' )
        dictionary.setString( fix.POSTGRESQL_LOG_USER, 'db_user' )
        dictionary.setString( fix.POSTGRESQL_LOG_PASSWORD, 'db_password' )
        dictionary.setString( fix.POSTGRESQL_LOG_HOST, 'localhost' )

        self.settings.set( sessionID, dictionary )
        self.factory = fix.PostgreSQLStoreFactory( self.settings )
        self.object = self.factory.create( sessionID )

    def test_message_store_set_get(self):
        self.object.reset()

        logon = fix42.Logon()
        logon.getHeader().setField( fix.MsgSeqNum( 1 ) )
        self.object.set( 1, logon.toString() )

        hb = fix42.Heartbeat()
        hb.getHeader().setField( fix.MsgSeqNum( 2 ) )
        self.object.set( 2, hb.toString() )

        nos = fix42.NewOrderSingle()
        nos.getHeader().setField( fix.MsgSeqNum( 3 ) )
        self.object.set( 3, nos.toString() )

        messages = fix.StringVector()
        self.object.get( 1, 3, messages )
        self.assertEqual( 3, len( messages ) )
        self.assertEqual( logon.toString(), messages[0] )
        self.assertEqual( hb.toString(), messages[1] )
        self.assertEqual( nos.toString(), messages[2] )

        self.object.get( 4, 6, messages )
        self.assertEqual( 0, len( messages ) )

        self.object.get( 2, 6, messages )
        self.assertEqual( 2, len( messages ) )
        self.assertEqual( hb.toString(), messages[ 0 ] )
        self.assertEqual( nos.toString(), messages[ 1 ] )

    def test_message_store_set_get_with_quote(self):
        self.object.reset()

        singleQuote = fix42.ExecutionReport()
        singleQuote.setField( fix.Text("Some Text") )
        self.object.set( 1, singleQuote.toString() )

        doubleQuote = fix42.ExecutionReport()
        doubleQuote.setField( fix.Text("\"Some Text\"") )
        self.object.set( 2, doubleQuote.toString() )

        bothQuote = fix42.ExecutionReport()
        bothQuote.setField( fix.Text("'\"Some Text\"'") )
        self.object.set( 3, bothQuote.toString() )

        escape = fix42.ExecutionReport()
        escape.setField( fix.Text("\\Some Text\\") )
        self.object.set( 4, escape.toString() )
        messages = fix.StringVector()
        self.object.get( 1, 4, messages )

        self.assertEqual( 4, len( messages ) )
        self.assertEqual( singleQuote.toString(), messages[0] )
        self.assertEqual( doubleQuote.toString(), messages[1] )
        self.assertEqual( bothQuote.toString(), messages[2] )
        self.assertEqual( escape.toString(), messages[3] )

    def test_message_store_other(self):
        self.object.reset()

        self.object.setNextSenderMsgSeqNum( 10 )
        self.assertEqual( 10, self.object.getNextSenderMsgSeqNum() )

        self.object.setNextTargetMsgSeqNum( 20 )
        self.assertEqual( 20, self.object.getNextTargetMsgSeqNum() )

        self.object.incrNextSenderMsgSeqNum()
        self.assertEqual( 11, self.object.getNextSenderMsgSeqNum() )

        self.object.incrNextTargetMsgSeqNum()
        self.assertEqual( 21, self.object.getNextTargetMsgSeqNum() )

        self.object.setNextSenderMsgSeqNum( 5 )
        self.object.setNextTargetMsgSeqNum( 6 )

    def test_message_store_reload(self):
        self.assertEqual( 5, self.object.getNextSenderMsgSeqNum() )
        self.assertEqual( 6, self.object.getNextTargetMsgSeqNum() )

    def test_message_store_refresh(self):
        self.object.refresh()
        self.assertEqual( 5, self.object.getNextSenderMsgSeqNum() )
        self.assertEqual( 6, self.object.getNextTargetMsgSeqNum() )

if __name__ == '__main__':
    unittest.main()
