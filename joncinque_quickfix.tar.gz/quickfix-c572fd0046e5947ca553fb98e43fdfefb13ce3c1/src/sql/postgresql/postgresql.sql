\i sessions_table.sql;
\i messages_table.sql;
\i messages_log_table.sql;
\i event_log_table.sql;
