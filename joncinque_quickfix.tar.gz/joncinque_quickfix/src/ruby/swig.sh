#!/bin/sh

swig -I../C++ -ruby -c++ -o QuickfixRuby.cpp quickfix.i
